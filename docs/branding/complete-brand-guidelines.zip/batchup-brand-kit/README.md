# BatchUp Brand Assets — v1.0

## Icons
- `app-icon.svg` / `icon-mark.svg` — vector masters, infinitely scalable. `icon-mark.svg` uses `currentColor` so it can be recolored via CSS.
- `icon-square-1024.png` — full-bleed, no baked corner radius. Use this as the **source upload for App Store Connect / Play Console** — both platforms apply their own corner mask, so a pre-rounded icon here would double-round.
- `icon-rounded-1024.png` + resized set (16 / 32 / 48 / 96 / 152 / 167 / 180 / 192 / 256 / 512) — the squircle version, for favicons, web manifests, and anywhere the OS doesn't auto-mask.
- `icon-dark-alt-1024.png`, `icon-tinted-1024.png` — iOS 18+ supports light/dark/tinted app icon variants. Dark-alt = Ink bg / Highlighter mark. Tinted = monochrome, for the system-tinted icon mode.
- `favicon.ico`, `apple-touch-icon.png` (180×180, flattened onto Highlighter — iOS ignores transparency), `android-chrome-192.png`, `android-chrome-512.png` — drop straight into your `public/` folder.

## Wordmark
- `wordmark-on-dark.png`, `wordmark-on-light.png` — transparent-background lockups for decks, docs, email signatures.

## Share card
- `og-image.png` (1200×630) — use for `og:image` and `twitter:image`. This is the card that renders when a batchup.fun link unfurls in WhatsApp, iMessage, Discord, or Slack.

## Engineering tokens
- `tokens.css` — CSS custom properties, ready to import as-is.
- `tokens.json` — same values, structured for JS build tools or a Figma tokens plugin.
- `tailwind.tokens.js` — drop into `tailwind.config.js` under `theme.extend`.

## One honest note on fonts
The live brand guidelines doc and the landing page load **Cabinet Grotesk, Inter, and Space Mono** from Fontshare/Google Fonts CDNs — use those for anything that renders in a browser.

The flattened raster files in this package (icons, wordmark PNGs, OG card) were baked using **Poppins** as the display substitute instead. This isn't a shortcut: app icons, favicons, and OG images are static pixels served to platforms that can't load a webfont anyway (iOS home screen, WhatsApp's link-preview renderer, etc.), so they need to be flattened with an embedded/system font regardless of who generates them. Poppins is a genuine geometric-rounded match for Cabinet Grotesk's character, not just a stand-in — several production apps use it as their actual display face. If you later license Cabinet Grotesk as a static file, re-run the export with it swapped in for pixel-perfect match; nothing else about the files changes.

## What's still open
- The two logo paths are the same mark used throughout the guidelines doc — no changes made here.
- No square/1:1 OG variant included (the 1200×630 standard covers WhatsApp, iMessage, Discord, Slack, and Twitter/X large-card previews).
