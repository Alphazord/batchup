// BatchUp — Tailwind theme extension
// Merge this into tailwind.config.js under theme.extend

module.exports = {
  theme: {
    extend: {
      colors: {
        ink:         { DEFAULT: '#12132A', 2: '#1B1D3D', 3: '#262952' },
        paper:       { DEFAULT: '#EDEBFA', dim: '#C9C7DE' },
        highlighter: { DEFAULT: '#DFFF4F', dim: '#B9D63F' },
        marker:      { DEFAULT: '#FF5C7D', dim: '#D64A67' },
        cobalt:      '#6B7CFF',
        signal:      '#FF3B3B',
        online:      '#3DE0A0',
      },
      fontFamily: {
        display: ['Cabinet Grotesk', 'Poppins', '-apple-system', 'Segoe UI', 'sans-serif'],
        body: ['Inter', '-apple-system', 'Segoe UI', 'Roboto', 'Helvetica', 'Arial', 'sans-serif'],
        mono: ['Space Mono', 'SFMono-Regular', 'Consolas', 'Liberation Mono', 'monospace'],
      },
      borderRadius: {
        lg: '22px',
        md: '14px',
        sm: '8px',
      },
      borderWidth: {
        DEFAULT: '2.5px',
      },
      transitionTimingFunction: {
        snap: 'cubic-bezier(0.16, 1, 0.3, 1)',
      },
    },
  },
};
